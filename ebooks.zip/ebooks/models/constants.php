<?php 
define("EBOOKS_DIR", "uploaded_ebooks");
define("EBOOKS_SERVER_PATH", $_SERVER['SERVER_NAME']."/iep/ebooks/uploaded_ebooks/");
define("EBOOKS_PATH", "../uploaded_ebooks/");
define("EBOOKS_CONTROLLER", $_SERVER['SERVER_NAME']."/iep/ebooks/controllers/");

?>