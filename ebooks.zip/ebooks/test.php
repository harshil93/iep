<?php 
	include '/iep/index.php';
 ?>